<html>
<head>
    <title>Admin LMS</title>
</head>

<body>
<h1>LMS</h1>
<BR>

<input type="submit" value="Add Books" style="width:150px" onclick="window.location.href='addbook.php'">
<input type="submit" value="Remove Books" style="width:150px" onclick="">




</form>


</body>
</html>