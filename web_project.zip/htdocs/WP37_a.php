<html>
<head>
<title>
</title>
</head>
<body bgcolor="sky blue">
<font color="red"><marquee direction="right" behaviour="sliding" onMouseOver="this.stop()" onMouseOut="this.start()"><h2>WELCOME TO FRESHERS WORLD!!!</h2></marquee></font>
<form >
<fieldset><legend>REGISTRATION FORM</legend>
<table border="1">
<tr>
<td>Name </td><td><input type= "text" name="name"></td><br><br>
</tr>
<tr>
<td>Age</td><td><select name = "age" value="SELECT">
    <?php
    for($i=1;$i<=100;$i++){
        echo"<option>".$i."</option>";
    }
    ?>    
    </select></td>
</tr>
<tr>
<td>Password</td> <td><input type="password" name="pass"></td>
</tr>
<tr>
<td>Re-enter Password</td><td><input type="password" name="repass"></td>
</tr>
<tr>
<td rowspan="5">Select your security question</td>
<tr><td><input type = "radio" name="pet"> What is your pet name?</td></tr>
<tr><td><input type = "radio" name="best"> Who is your best friend?</td></tr>
<tr><td><input type = "radio" name="best"> What is favourite color?</td></tr>
<tr><td><input type = "radio" name="best"> Who is your favourite teacher?</td></tr>
</tr>

<tr>
<td>Answer of Security Question</td><td><input type="text" name="answer">
</tr>
<tr>
<td>Email ID</td><td><input type="email" name="email">
</tr>
<tr>
<td>Languages Known</td>
<td>
    <input type="checkbox" name="language" value="Malayalam">Malayalam
    
    <input type="checkbox" name="language" value="ENGLISH">ENGLISH
    
    <input type="checkbox" name="language" value="hindi">Hindi
</td>
</tr>

<tr>
<td>Upload Photo</td> <td><input type="file" size="2"></td>
</tr>
<tr>
<td><input type="Reset"></td> <td><input type="Submit"></td>
</tr>
</table>


</body>
</html>
