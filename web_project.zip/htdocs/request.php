<html>
<head>
<title>
</title>
</head>
<body>
<form action="" method="POST">
<table>
<tr><td>
<h2>Request Book</h2>
</td></tr>
<tr>
<td><input type= "text" name="name" placeholder="Book Name"></td><br><br>
</tr>
<tr>
<td><br><input type="text" name = "id" placeholder="Author" >
</tr>
<tr>
<td><br><input type="submit" value = "Request"></td> 
</tr>
</table>
</form>

</body>
</html>