<?php
$name = $_GET["name"];
echo $name;
$age = $_GET["age"];
echo $age;
$pass = $_GET["pass"];
echo $pass;
$email = $_GET["email"];
echo $email;

$servername="localhost";
$username="root";
$password="";
$dbname = "ham";
$conn = mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
    die("Registration failed".mysqli_connect_error());
}
echo "Registration successful";
// $sq = "insert into table_37 values('$name','$age','$pass','$email')";
// echo "All Datas submitted to database successfully"

?>